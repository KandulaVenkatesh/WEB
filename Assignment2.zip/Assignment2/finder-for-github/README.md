# Finder for Github Users

Inspired by [Traversy Media on Youtube](https://www.youtube.com/watch?v=lIKrfLWNsUI)

As the header says, it finds any github user and his available public repos upon input.

This will work as-is but on a limited number of searches. To tackle this, add a new github app and then use the client id and client secret in js/main.js to both the ajax data attribute.

[Kam Curacha](https://curacha.me)