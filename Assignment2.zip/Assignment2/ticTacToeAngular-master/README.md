# ticTacToeAngular
A tic-tac-toe game written in Angular JS.

Just open index.html. You can step through the JS code using Chrome developer tools (or Firebug or something similar).
